
### Features of Stage 3:
##### On Space button pressed, player gets a second chance to play
##### Score card is calculated 
##### Blocks are vanished on coming in contact with my slingshot


## Use basic p5.play-boilerplate
Boiler plate for p5.play : https://github.com/vishnupriya-whitehatjr/BasicLibFiles

## Please refer to code notes for explanation.

### Output Link : https://vishnupriya-whitehatjr.github.io/c32-v2-TowerSiege-Stage3/ 
(download and check output as it is connected to API).

